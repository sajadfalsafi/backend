from django.contrib import admin
from .models import Footer, FooterLink
# Register your models here.

admin.site.register(Footer)
admin.site.register(FooterLink)