from django.contrib import admin
from .models import Copyright
# Register your models here.

admin.site.register(Copyright)