from django.contrib import admin
from .models import CopyRight, Social
# Register your models here.

admin.site.register(CopyRight)
admin.site.register(Social)