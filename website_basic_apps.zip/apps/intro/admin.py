from django.contrib import admin
from .models import Intro
# Register your models here.


admin.site.register(Intro)