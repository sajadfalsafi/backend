from django.contrib import admin
from .models import Steps
# Register your models here.

admin.site.register(Steps)